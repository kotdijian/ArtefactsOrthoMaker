from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import trimesh


UNIT_TO_MM = {
    "mm": 1.0,
    "cm": 10.0,
    "m": 1000.0,
}


def sha256_file(path: str | Path, chunk_size: int = 4 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def load_normalized_ply(path: str | Path) -> trimesh.Trimesh:
    path = Path(path)
    if path.suffix.lower() != ".ply":
        raise ValueError("LithMorph v0.1.0-dev1 accepts normalized PLY input only.")

    loaded = trimesh.load(path, force=None, process=False)

    if isinstance(loaded, trimesh.Scene):
        geometries = [
            g for g in loaded.geometry.values()
            if isinstance(g, trimesh.Trimesh)
        ]
        if not geometries:
            raise ValueError("No mesh geometry found in PLY.")
        mesh = trimesh.util.concatenate(geometries)
    elif isinstance(loaded, trimesh.Trimesh):
        mesh = loaded
    else:
        raise TypeError(f"Unsupported Trimesh load result: {type(loaded)!r}")

    if len(mesh.vertices) == 0 or len(mesh.faces) == 0:
        raise ValueError("Mesh contains no vertices or faces.")

    if mesh.faces.shape[1] != 3:
        mesh = mesh.triangulate()

    return mesh


def resolve_units(
    ply_path: str | Path,
    input_unit: str | None = None,
) -> tuple[str, float, dict | None]:
    """Resolve coordinate unit from explicit input or sibling transform.json."""
    ply_path = Path(ply_path)

    if input_unit is not None and input_unit != "auto":
        unit = input_unit.lower()
        if unit not in UNIT_TO_MM:
            raise ValueError(f"Unsupported input unit: {input_unit}")
        return unit, UNIT_TO_MM[unit], None

    transform_path = ply_path.parent / "transform.json"
    if transform_path.exists():
        data = json.loads(transform_path.read_text(encoding="utf-8"))
        source = data.get("source", {})
        unit = str(source.get("input_unit", "")).lower()
        factor = source.get("unit_to_mm", None)
        if unit in UNIT_TO_MM and factor is not None:
            return unit, float(factor), data

    raise ValueError(
        "Unit could not be resolved automatically. "
        "Place ArtefactsOrthoMaker transform.json beside the PLY, "
        "or specify --unit mm|cm|m."
    )


def mesh_qa(mesh: trimesh.Trimesh) -> dict:
    bounds = np.asarray(mesh.bounds, dtype=float)
    ext = bounds[1] - bounds[0]
    result = {
        "vertex_count": int(len(mesh.vertices)),
        "face_count": int(len(mesh.faces)),
        "bbox_native": bounds.tolist(),
        "bbox_extents_native": ext.tolist(),
        "is_watertight": bool(mesh.is_watertight),
        "is_winding_consistent": bool(mesh.is_winding_consistent),
        "euler_number": int(mesh.euler_number),
    }
    try:
        result["body_count"] = int(mesh.body_count)
    except Exception:
        result["body_count"] = None
    return result
