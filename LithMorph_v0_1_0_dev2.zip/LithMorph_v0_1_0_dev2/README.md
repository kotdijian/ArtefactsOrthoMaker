# LithMorph

**LithMorph** is a surface-based morphometric analysis tool for normalized lithic 3D models.

This repository snapshot is the first geometry-core implementation:

```text
Version: 0.1.0-dev2
Status: core-first development build
```

The intended upstream input is the normalized PLY produced by ArtefactsOrthoMaker:

```text
<stem>_rev.ply
transform.json
```

LithMorph treats the PLY as the surface of a solid lithic object. It does **not**
voxelize the object. Basic analysis is based on the XY planform projection and
serial intersections between the triangle surface and XZ / YZ planes.

## Coordinate convention

```text
X = width
Y = length
Z = thickness

Planform              = XY
Transverse sections   = XZ (y = constant)
Longitudinal sections = YZ (x = constant)
```

## Sampling presets

The user selects one base sampling density:

```text
Sparse  = 9
Low     = 25
Default = 49
High    = 99
```

The actual XZ/YZ counts are adapted to the normalized PLY bbox:

```text
r = bbox_y / bbox_x

Y > 2X:
    XZ = N
    YZ = approximately N/2

X/2 <= Y <= 2X:
    XZ = N
    YZ = N

Y < X/2:
    XZ = approximately N/2
    YZ = N
```

The reduced counts remain odd so that the central 50% section is always present:

```text
9  -> 5
25 -> 13
49 -> 25
99 -> 49
```

All section locations are defined by:

```text
position(k) = k / (N + 1), k = 1 ... N
```

so 0% and 100% bbox tangency planes are excluded.

## Basic analysis implemented in dev1

### XY planform

The planform is projected directly from the triangle surface using Trimesh's
projected-polygon routine. It is independent of the selected XZ section count.

Outputs include:

- planform area
- planform perimeter
- planform centroid
- dense width profile
- centerline profile
- maximum width
- maximum-width position
- left/right points defining maximum width

Maximum-width position is reported from `Ymin = 0%` to `Ymax = 100%`.
It is deliberately kept separate from future ellipticity / sharpness measures.
No "99% maximum-width plateau" criterion is used. Only numerically tied maxima
are averaged to resolve a non-unique flat maximum.

### Serial XZ and YZ sections

Every selected section stores its contour topology and calculates, where valid:

- contour perimeter
- enclosed area
- enclosed-area centroid
- section bbox extents
- open-contour length
- component count
- topology status

Each contour component is also resampled to 256 points by default.

For XZ:

```text
u = X
v = Z
centroid = (Cx, Cz)
```

For YZ:

```text
u = Y
v = Z
centroid = (Cy, Cz)
```

`contour_perimeter`, `enclosed_area`, and centroid are therefore **per-section
values**, not only aggregate statistics. Later summary statistics can be derived
from the complete profile.

Open contours are retained as surface information but are not force-closed.
Large gaps are never bridged automatically.

## Output

Default output directory:

```text
<PLY directory>/lithic_surface_analysis/
```

Files:

```text
summary.json
qa.json
planform_profile.csv
planform_outline.csv
section_summary.csv
section_points.csv
```

`section_summary.csv` contains one row per section.

`section_points.csv` contains the resampled contour points, preserving component,
closed/open, and branch information.

## Optional-analysis architecture

Basic analysis is always executed for every input PLY.

Optional metrics are implemented as independent registered analyzers under:

```text
lithmorph/optional/
```

The basic pipeline does not depend on optional modules.

Planned optional analyses include:

- planform ellipticity / sharpness
- planform / section symmetry
- Y-axis twist
- YZ straightness / curvature
- additional descriptors to be defined later

These are intentionally **not implemented** in `0.1.0-dev2`; the extension
interface is already present so they can be added without changing the core
geometry pipeline.

## Installation

```bash
python -m venv venv
source venv/bin/activate
python -m pip install -r requirements.txt
```

Windows PowerShell:

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

## Run

When `transform.json` is beside the normalized PLY:

```bash
python analyze.py /path/to/specimen_rev.ply
```

Sampling preset:

```bash
python analyze.py /path/to/specimen_rev.ply --preset Sparse
python analyze.py /path/to/specimen_rev.ply --preset Low
python analyze.py /path/to/specimen_rev.ply --preset Default
python analyze.py /path/to/specimen_rev.ply --preset High
```

If `transform.json` is unavailable:

```bash
python analyze.py /path/to/specimen_rev.ply --unit mm
```

## Tests

```bash
pytest -q
python self_test.py
```

The initial tests use synthetic rectangular solids with analytically known
planform and section values.

## Development sequence

1. Validate section geometry and adaptive sampling on synthetic meshes.
2. Benchmark Sparse / Low / Default / High on approximately 0.7–1.0M-face PLY.
3. Benchmark higher-density meshes and optimize repeated slicing if needed.
4. Add GUI only after the geometry core and performance behavior are validated.
5. Add optional morphology modules through the registry.

## Benchmark utility

`benchmark.py` loads the mesh once, constructs the reusable slicer once, computes
the dense planform once, and then benchmarks all four serial-section presets.

```bash
python benchmark.py /path/to/specimen_rev.ply --out benchmark_result
```

It writes `benchmark.csv` and `benchmark.json`. For watertight meshes it also
reports a diagnostic cross-sectional volume reconstruction error. This diagnostic
is used to validate serial-section geometry; LithMorph is not a pottery-style
volume-calculation application.
